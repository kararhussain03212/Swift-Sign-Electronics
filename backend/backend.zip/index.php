<?php

declare(strict_types=1);

use Backend\Middleware\CorsMiddleware;
use Backend\Config\Env;
use Backend\Utils\Response;
use Backend\Utils\Router;

require_once __DIR__ . '/config/env.php';
require_once __DIR__ . '/middleware/cors.php';
require_once __DIR__ . '/utils/Response.php';
require_once __DIR__ . '/utils/Router.php';
require_once __DIR__ . '/routes/api.php';

CorsMiddleware::handle();
Env::load(__DIR__ . '/.env');

$appEnv = Env::get('APP_ENV', 'local');
if ($appEnv === 'production') {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
    error_reporting(E_ALL);
    ini_set('log_errors', '1');
} else {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
}

$host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
$host = trim(explode(':', $host)[0] ?? '');
$isLocalHost = in_array($host, ['localhost', '127.0.0.1', '::1'], true);
$httpsEnabled = ($_SERVER['HTTPS'] ?? '') === 'on' || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
if ($appEnv === 'production' && !$httpsEnabled && !$isLocalHost) {
    Response::error('HTTPS is required in production', 403);
}

$router = new Router();
registerApiRoutes($router);

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$apiPos = strpos($path, '/api/');
if ($apiPos !== false) {
    $path = substr($path, $apiPos);
}

try {
    $router->dispatch($method, $path);
} catch (Throwable $e) {
    error_log(sprintf(
        '[unhandled] %s: %s in %s:%d',
        get_class($e),
        $e->getMessage(),
        $e->getFile(),
        $e->getLine()
    ));

    // Never leak internals (SQL text, file paths, stack traces) to the client in
    // production; only show the real message locally where it aids debugging.
    $message = $appEnv === 'production' ? 'Server error. Please try again later.' : 'Server error: ' . $e->getMessage();
    Response::error($message, 500);
}
